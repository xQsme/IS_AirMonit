CREATE TABLE [dbo].[CITIES] (
    [Id]        INT        IDENTITY (1, 1) NOT NULL,
    [name]      NCHAR (50) NOT NULL,
    [latitude]  FLOAT (53) NOT NULL,
    [longitude] FLOAT (53) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

