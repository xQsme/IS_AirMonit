CREATE TABLE [dbo].[CityAverage] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [Year]     SMALLINT       DEFAULT (datepart(year,getdate())) NULL,
    [MONTH]    SMALLINT       DEFAULT (datepart(month,getdate())) NULL,
    [WEEK]     SMALLINT       DEFAULT (datepart(week,getdate())) NULL,
    [cityId]   INT            NOT NULL,
    [particle] NCHAR (5)      NOT NULL,
    [sum]      BIGINT         DEFAULT ((0)) NULL,
    [count]    INT            DEFAULT ((0)) NULL,
    [average]  DECIMAL (6, 2) DEFAULT ((0)) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([cityId]) REFERENCES [dbo].[CITIES] ([Id])
);

