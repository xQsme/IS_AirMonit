CREATE TABLE [dbo].[Sensors] (
    [Id]     INT            IDENTITY (1, 1) NOT NULL,
    [name]   NVARCHAR (20)  NOT NULL,
    [value]  DECIMAL (6, 2) NOT NULL,
    [date]   DATETIME       NOT NULL,
    [cityId] INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([cityId]) REFERENCES [dbo].[CITIES] ([Id])
);

