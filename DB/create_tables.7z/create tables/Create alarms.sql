CREATE TABLE [dbo].[Alarms] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [Particle]        NVARCHAR (50)  NOT NULL,
    [Condition]       NVARCHAR (10)  NOT NULL,
    [ConditionValue1] NUMERIC (6, 2) NOT NULL,
    [ConditionValue2] NUMERIC (6, 2) NULL,
    [EntryValue]      NUMERIC (6, 2) NOT NULL,
    [Message]         NVARCHAR (100) NOT NULL,
    [Date]            DATETIME       NOT NULL,
    [CityId]          INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([CityId]) REFERENCES [dbo].[CITIES] ([Id])
);
