CREATE TABLE [dbo].[Events] (
    [Id]   INT        IDENTITY (1, 1) NOT NULL,
    [name] NCHAR (30) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

