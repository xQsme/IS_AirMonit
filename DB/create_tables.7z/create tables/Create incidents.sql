CREATE TABLE [dbo].[Incidents] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [message]    NVARCHAR (160) NOT NULL,
    [otherEvent] NCHAR (30)     NULL,
    [eventId]    INT            NULL,
    [publisher]  NCHAR (30)     NOT NULL,
    [date]       DATETIME       NOT NULL,
    [cityId]     INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([eventId]) REFERENCES [dbo].[Events] ([Id]),
    FOREIGN KEY ([cityId]) REFERENCES [dbo].[CITIES] ([Id])
);

